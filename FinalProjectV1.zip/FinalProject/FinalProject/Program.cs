﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class Program
    {
        static void Main(string[] args)
        {
            int fr = 0;
            string userResponse;
            int responseVal;
            while(fr != 1)
            {
                Console.WriteLine("Vault-Tec Rep: Good Morning! Vault-Tec calling!");
                Console.WriteLine("===============================================");
                Console.WriteLine("1: Vault-Tec?");
                Console.WriteLine("2: I'm not interested in whatever you're selling.");
                Console.WriteLine("3: Good Morning");
                Console.WriteLine("4: I'm listening");
                userResponse = Console.ReadLine();
                responseVal = Convert.ToInt32(userResponse);
                if(responseVal == 1)
                {
                    Console.WriteLine("You chose confused/qustioning");
                }
                else if(responseVal == 2)
                {
                    Console.WriteLine("You chose dismissive/negative");

                }
                else if(responseVal == 3)
                {
                    Console.WriteLine("You chose pleasant/positive");

                }
                else if(responseVal == 4)
                {
                    Console.WriteLine("You chose sarcastic/rude");

                }
                else
                {
                    Console.WriteLine("You chose an invalid option");
                }
                Console.WriteLine();
                Console.WriteLine("Vault-Tec Rep: You can't begin to know how happy I am to finally speak with you.");
                Console.WriteLine("               I've been trying for days. Its a matter of utmost urgency, I assure you.");
                Console.WriteLine("===============================================");
                Console.WriteLine("1: What's so important?");
                Console.WriteLine("2: Maybe I don't want to talk to you.");
                Console.WriteLine("3: Then I'm glad you caught up with me.");
                Console.WriteLine("4: I'm here now.");
                userResponse = Console.ReadLine();
                responseVal = Convert.ToInt32(userResponse);
                if (responseVal == 1)
                {
                    Console.WriteLine("You chose confused/qustioning");
                }
                else if (responseVal == 2)
                {
                    Console.WriteLine("You chose dismissive/negative");

                }
                else if (responseVal == 3)
                {
                    Console.WriteLine("You chose pleasant/positive");

                }
                else if (responseVal == 4)
                {
                    Console.WriteLine("You chose sarcastic/rude");

                }
                else
                {
                    Console.WriteLine("You chose an invalid option");
                }
            }
        }
    }
}
