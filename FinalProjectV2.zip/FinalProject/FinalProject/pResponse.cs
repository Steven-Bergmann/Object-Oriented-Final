﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class pResponse
    {
        int level;

        public pResponse(int _level)
        {
            level = _level;
        }

        public void response()
        {
            if (level == 1)
            {
                Console.WriteLine("Good morning.");
                message VTR = new message(7);
                VTR.NPCtext();
                return;
            }
            if (level == 2)
            {
                Console.WriteLine("Then I'm glad you caught up with me.");
                message VTR = new message(15);
                VTR.NPCtext();
                VTR = new message(5);
                VTR.NPCtext();
                VTR = new message(4);
                VTR.NPCtext();
                return;
            }
            if (level == 3)
            {
                Console.WriteLine("Sounds great.");
                message VTR = new message(16);
                VTR.NPCtext();
                
            }
            else
            {
                Console.WriteLine("INVALID");
                return;
            }
        }
    }
}
