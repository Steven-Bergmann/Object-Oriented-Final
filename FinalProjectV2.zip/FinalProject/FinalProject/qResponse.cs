﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class qResponse
    {
        int level;

        public qResponse(int _level)
        {
            level = _level;
        }

        public void response()
        {
            if(level == 1)
            {
                Console.WriteLine("Vault-Tec? Remind me again.");
                message VTR = new message(10);
                VTR.NPCtext();
                return;
            }
            if(level == 2)
            {
                Console.WriteLine("What's so important?");
                message VTR = new message(12);
                VTR.NPCtext();
                VTR = new message(5);
                VTR.NPCtext();
                return;
            }
            if(level == 3)
            {
                Console.WriteLine("But there's room for my entire family, right?");
                message VTR = new message(13);
                VTR.NPCtext();
                VTR = new message(14);
                VTR.NPCtext();
                return;
            }
            else
            {
                Console.WriteLine("INVALID");
                return;
            }
        }
    }
}
