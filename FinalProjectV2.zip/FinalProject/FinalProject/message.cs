﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class message
    {
        int level;
        

        public message(int _level)
        {
            level = _level;
        }

        public void NPCtext()
        {
            if (level == 0)
            {
                Console.WriteLine("Vault-Tec Rep: Good Morning! Vault-Tec calling!");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 1)
            {
                Console.WriteLine("Vault-Tec Rep: You can't begin to know how happy I am to finally speak with you.");
                Console.WriteLine("               I've been trying for days. Its a matter of utmost urgency, I assure you.");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 5)
            {
                Console.WriteLine("Vault-Tec Rep: Now, I know your a busy person, so I won't take up much of your time, ");
                Console.WriteLine("               time being a, um, precious commodity...");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 4)
            {
                Console.WriteLine("Vault-Tec Rep: I'm here today to tell you that because of your family's service to our country, ");
                Console.WriteLine("               you have been pre-selected for entracne into your local vault! Vault 111!");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 3)
            {
                Console.WriteLine("Vault-Tec Rep: I just need to verify some information. That's all!");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 6)
            {
                Console.WriteLine("Vault-Tec Rep: Wonderfull! That's.. everything... Just gonna walk this over to the Vault!");
                Console.WriteLine("Congratulations on being prepared for the future!");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 7)
            {
                Console.WriteLine("Vault-Tec Rep: Isn't it! Just look at that sky out there! *clears throat*");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 8)
            {
                Console.WriteLine("Vault-Tec Rep: Oh, no worries, sir. No worries at all! I'm not selling anything. Not today.");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 9)
            {
                Console.WriteLine("Vault-Tec Rep: Nice to find you sir");
                Console.WriteLine("===============================================");
                Console.WriteLine();
                return;
            }
            if (level == 10)
            {
                Console.WriteLine("Vault-Tec Rep: Why we're about you sir! And helping secure your future.");
                Console.WriteLine("               You see, Vault-Tec is the foremost builder of state of the art underground fallout shelters");
                Console.WriteLine("===========================================================================");
                Console.WriteLine();
                return;
            }
            if (level == 11)
            {
                Console.WriteLine("Vault-Tec Rep: Oh, *coughs nervously* you do.");
                Console.WriteLine("===========================================================================");
                Console.WriteLine();
                return;
            }
            if (level == 12)
            {
                Console.WriteLine("Vault-Tec Rep: Why nothing less than your entire future!");
                Console.WriteLine("               If you haven't noticed sir, this country has gone to heck in a handbasket");
                Console.WriteLine("               If you'll excuse my language. The big kaboom is... its inevitble I'm afraid.");
                Console.WriteLine("               And coming sooner than you might think.");
                Console.WriteLine("============================================================================");
                Console.WriteLine();
                return;
            }
            if (level == 13)
            {
                Console.WriteLine("Vault-Tec Rep: Of course. Of course! Minus your robot, naturally.");
                Console.WriteLine("               In fact, you're already cleared for entrance.");
                Console.WriteLine("               Its just a matter of verifying some information.");
                Console.WriteLine("=============================================================================");
                Console.WriteLine();
                return;
            }
            if (level == 14)
            {
                Console.WriteLine("Vault-Tec Rep: Don't want there to be any holdups, in the unforseen event of *ahem*");
                Console.WriteLine("               Total Atomic Annihilation. Won't take but a moment");
                Console.WriteLine();
            }
            if(level == 15)
            {
                Console.WriteLine("Vault-Tec Rep: Oh, me too! You have no idea...");
                Console.WriteLine();
                return;
            }
            if(level == 16)
            {
                Console.WriteLine("Vault-Tec Rep: Oh, it is. Believe you me. Now you're already cleared for entrance,");
                Console.WriteLine("               in the unforseen event of *ahem* total atomic annihilation");
                Console.WriteLine();
                return;
            }
            //else
            //{
            //    Console.WriteLine("No Valid choice");
            //}
                
            
        }
    }
}
