﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class sResponse
    {
        int level;

        public sResponse(int _level)
        {
            level = _level;
        }

        public void response()
        {
            if (level == 1)
            {
                Console.WriteLine("Go on.");
                Console.WriteLine();
                message VTR = new message(9);
                VTR.NPCtext();
                return;
            }
            if (level == 2)
            {
                Console.WriteLine("I'm here now.");
                Console.WriteLine();
                message VTR = new message(18);
                VTR.NPCtext();
                VTR = new message(5);
                VTR.NPCtext();
                VTR = new message(4);
                VTR.NPCtext();
                return;
            }
            if(level == 3)
            {
                Console.WriteLine("I'm a little busy right now.");
                Console.WriteLine();
                message VTR = new message(19);
                VTR.NPCtext();
            }
            
        }
    }
}
