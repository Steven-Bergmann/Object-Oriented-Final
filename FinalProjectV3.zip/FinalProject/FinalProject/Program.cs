﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class Program
    {
        static void Main(string[] args)
        {
            int fr = 0;
            string userResponse;
            int responseVal;
            int Level = 1;
            int NPClevel = 0;
            
            while(fr != 1)
            {
                if (Level > 4)
                {
                    break;
                }
                message VTR = new message(NPClevel);
                VTR.NPCtext();

                showDialouge choices = new showDialouge(NPClevel);
                choices.showChoices();
                
                userResponse = Console.ReadLine();
                responseVal = Convert.ToInt32(userResponse);
                Console.WriteLine();
                if (responseVal > 4 || responseVal < 1)
                {
                    Console.WriteLine("You chose an invalid option");
                }
                else if (responseVal == 1)
                {                    
                    qResponse response = new qResponse(Level);
                    response.response();
                    Console.WriteLine();                    
                }
                else if(responseVal == 2)
                {                  
                    nResponse response = new nResponse(Level);
                    response.response();
                    Console.WriteLine();                    
                }
                else if(responseVal == 3)
                {                    
                    pResponse response = new pResponse(Level);
                    response.response();
                    Console.WriteLine();                    
                }
                else if(responseVal == 4)
                {            
                    sResponse response = new sResponse(Level);
                    response.response();
                    Console.WriteLine();                   
                }                
                NPClevel++;
                Level++;
            }

            string fName, lName;
            message goodbye = new message(20);
            goodbye.NPCtext();
            Console.WriteLine("First Name: ");
            fName = Console.ReadLine();
            Console.WriteLine("Last Name: ");
            lName = Console.ReadLine();

            Console.WriteLine("Your name is " + fName + " " + lName);
            Console.WriteLine();

            goodbye = new message(6);
            goodbye.NPCtext();

            Console.WriteLine("Press any key to quit");
            string exit = Console.ReadLine();
        }
    }
}
