﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class showDialouge
    {
        int level;

        public showDialouge(int _level)
        {
            level = _level;
        }

        public void showChoices()
        {
            if(level == 0)
            {
                Console.WriteLine("1: Vault-Tec?");
                Console.WriteLine("2: I'm not interested in whatever you're selling.");
                Console.WriteLine("3: Good Morning");
                Console.WriteLine("4: I'm listening");
                return;
            }
            if(level == 1)
            {
                Console.WriteLine("1: What's so important?");
                Console.WriteLine("2: Maybe I don't want to talk to you.");
                Console.WriteLine("3: Then I'm glad you caught up with me.");
                Console.WriteLine("4: I'm here now.");
                return;
            }
            if(level == 2)
            {
                Console.WriteLine("1: Enough room?");
                Console.WriteLine("2: Go away.");
                Console.WriteLine("3: Sounds great.");
                Console.WriteLine("4: I'm a little busy right now.");
                return;
            }
            if(level == 3)
            {
                Console.WriteLine("1: Sure. Let's do it.");
                Console.WriteLine("2: Sure. Let's do it.");
                Console.WriteLine("3: Sure. Let's do it.");
                Console.WriteLine("4: Sure. Let's do it.");
                return;
            }

        }


    }
}
