﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject
{
    class nResponse
    {
        int level;

        public nResponse(int _level)
        {
            level = _level;
        }

        public void response()
        {
            if (level == 1)
            {
                Console.WriteLine("Whatever you're seeling, I don't want it.");
                Console.WriteLine();
                message VTR = new message(8);
                VTR.NPCtext();
                return;
            }
            if (level == 2)
            {
                Console.WriteLine("Maybe I don't want to talk to you.");
                Console.WriteLine();
                message VTR = new message(11);
                VTR.NPCtext();
                VTR = new message(5);
                VTR.NPCtext();
                VTR = new message(4);
                VTR.NPCtext();
                return;
            }
            if (level == 3)
            {
                Console.WriteLine("Go away.");
                Console.WriteLine();
                message VTR = new message(17);
                VTR.NPCtext();
                return;

            }
            
            
        }
    }
}
